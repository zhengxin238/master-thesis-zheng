Dieses Verzeichnis beinhaltet die LaTeX-Pakete und Klassen, um das
Corporate Design der TU Clausthal mit LaTeX umzusetzen.

Aktuelle Version: 0.8.0

Im Verzeichnis "doc" sind die entsprechenden Dateien zur Dokumentation
der Klassen und Pakete enthalten.  Der Ordner "latex" enthält die
eigentlichen Klassen und Pakete.

Bitte beachten Sie: die im Corporate Design der TU Clausthal
vorgesehenen Schriften "ITC Stone Serif" und "ITC Stone Sans" sind
nicht Bestandteil dieses Archivs.  Sie müssen gesondert beim RZ
bestellt werden und entsprechend auf Ihrem PC installiert werden.  Die
Schriften sind lizenzpflichtig und dürfen daher nur auf dienstlichen
Geräten der TU Clausthal installiert werden!

Es empfiehlt sich, die Dateien in die entsprechenden Verzeichnissen
Ihrer TeX-Distribution zu kopieren.  Idealerweise sollten Sie dabei
die TDS (TeX Directory Structure) beachten.

Ob ein TeXLive-System (z. B. TeXLive, MacTeX, teTeX, zum Teil wohl
auch MikTeX) genutzt wird, kann man in einem Terminal (Linux, MacOS)
bzw. einem Command-Shell (Windows) wie folgt feststellen:

    tlmgr version

Das Programm "tlmgr" ist das Verwaltungswerkzeug einer
TeXLive-Installation.  Es steht kurz für TeXLive-Manager.

Damit kann man sich auch die aktuelle Konfiguration des TeX-Systems
ausgeben lassen:

    tlmgr conf

In dem Abschnitt "kpathsea variables" werden diejenigen Bereiche
angegbenen, in denen TeX nach seinen Dateien sucht.  Dabei werden
prinzipiell drei Speicherbeiche unterschieden:

  1) TEXMFDIST: Der Bereich, der den Verwaltern der Distribution
  vorbehalten bleibt, hier den TeXLive-Entwicklern.

  2) TEXMFLOCAL: Der Bereich des lokalen Systemverwalters

  3) TEXMFHOME: Der individuelle Bereich des jeweiligen Users

Wenn Sie Systemadministrstor einer Site (wie der TU Clausthal) sind
und in dem genannten Ordner über Schreibrechte verfügen, dann sollten
Sie die tuc-cd Pakete und Dateien im 2. Bereich (TEXMFLOCAL) ablegen.
Keinesfalls sollten Sie die Klassen und Pakete im 1. Bereich
(TEXMFDIST) ablegen, da sie beim nächsten Update des TeX-Systems ohne
Vorwarnung überschrieben werden.

Wenn Sie die TU-Clausthal-Klassen und Pakete im 2. Bereich ablegen,
dann dürfen Sie nicht vergessen, die TeX-Datenbank zu aktualisieren,
indem sie den Befehl

    mktexlsr

oder

    texhash

aufrufen.

Sollten Sie keine Schreibrechte für TEXMFLOCAL verfügen, dann müssen
Sie die Dateien in die persönlichen TeX-Verzeichnisse (TEXMFHOME)
kopieren. 

Das beiliegende BASH-Skript "install-tuc-cd" (lauffähig unter Linux
und MacOS, ggfs. auch unter neueren Windows-Systemen) versucht
selbständig herauszufinden, ob Sie für den 2. Bereich Schreibrechte
haben.  Falls ja, legt das Script die entsprechenden Unterordner

    $TEXMFLOCAL/doc/tex/latex/TUC
    $TEXMFLOCAL/tex/latex/TUC

an und kopiert die Dokumentationsdateien in den erstgenannten Ordner,
bzw. die Klassen und Pakete in den zweitgenannten Ordner.

Im Dokumentationsordner finden Sie eine Reihe von
Anwendungsbeispielen, mit denen die Benutzung der TUC-CD-Klassen
exemplarisch vorgeführt wird.  Im Wesentlichen finden Sie dort auch
die Datei tuc-thesis.tex, die eine ausführliche Anleitung zu den
TUC-CD-Klassen und Paketen enthält.  Gleichzeitig dient die
LaTeX-Datei dazu, ein Beispiel zu geben, wie man Abschlussarbeiten mit
der Klasse tuc-thesis in LaTeX dokumentieren kann.  Insbesondere zeigt
sie, wie man eine größere, umfangreiche Datei mit Hilfe des
\include-Befehls in mehrere kleinere Dateien aufspalten kann, was die
Bearbeitung und insbesondere die Fehlersuche erheblich vereinfachen
kann.
